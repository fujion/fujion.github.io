package org.acme;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.fujion.annotation.Component;
import org.fujion.annotation.Component.ChildTag;
import org.fujion.component.BaseComponent;
import org.fujion.component.BaseUIComponent;

@Component(tag = "accordionview", widgetModule = "acme-accordion", widgetClass = "AccordionView", parentTag = "*", childTag = @ChildTag("accordionpane"))
public class AccordionView extends BaseUIComponent {
    
    private static final Log log = LogFactory.getLog(AccordionView.class);
    
    private AccordionPane selectedPane;
    
    public AccordionView() {
    }
    
    @Override
    protected void initProps(Map<String, Object> props) {
        super.initProps(props);
        props.put("wclazz", "accordionview");
    }

    public AccordionPane getSelectedPane() {
        return selectedPane;
    }

    public void setSelectedPane(AccordionPane selectedPane) {
        validateIsChild(selectedPane);
        
        if (this.selectedPane != null) {
            this.selectedPane._setSelected(false, false, true);
        }
        
        this.selectedPane = selectedPane;
        
        if (selectedPane != null) {
            selectedPane._setSelected(true, false, true);
        }
    }
    
    @Override
    public void afterAddChild(BaseComponent child) {
        if (((AccordionPane) child).isSelected()) {
            setSelectedPane((AccordionPane) child);
        }
    }

    @Override
    public void afterRemoveChild(BaseComponent child) {
        if (child == selectedPane) {
            selectedPane = null;
        }
    }

}
