package org.acme;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.fujion.annotation.Component;
import org.fujion.annotation.Component.ChildTag;
import org.fujion.annotation.Component.PropertyGetter;
import org.fujion.annotation.Component.PropertySetter;
import org.fujion.annotation.EventHandler;
import org.fujion.component.BaseUIComponent;
import org.fujion.event.ChangeEvent;
import org.fujion.event.EventUtil;

@Component(tag = "accordionpane", widgetModule = "acme-accordion", widgetClass = "AccordionPane", parentTag = "accordionview", childTag = @ChildTag("*"))
public class AccordionPane extends BaseUIComponent {

    private static final Log log = LogFactory.getLog(AccordionPane.class);

    private boolean selected;

    private String label;

    public AccordionPane() {
    }

    @Override
    protected void _initProps(Map<String, Object> props) {
        super._initProps(props);
        props.put("wclazz", "accordionpane");
    }
    
    @PropertyGetter("label")
    public String getLabel() {
        return label;
    }
    
    @PropertySetter("label")
    public void setLabel(String label) {
        label = trimify(label);
        
        if (!areEqual(label, this.label)) {
            sync("label", this.label = label);
        }
    }

    @PropertyGetter("selected")
    public boolean isSelected() {
        return selected;
    }
    
    @PropertySetter("selected")
    public void setSelected(boolean selected) {
        _setSelected(selected, true, true);
    }

    protected void _setSelected(boolean selected, boolean notifyParent, boolean notifyClient) {
        if (selected != this.selected) {
            sync("selected", this.selected = selected);
            
            if (notifyParent && getParent() != null) {
                ((AccordionView) getParent()).setSelectedPane(selected ? this : null);
            }
        }
    }

    @Override
    public void bringToFront() {
        setSelected(true);
        super.bringToFront();
    }
    
    @EventHandler(value = "change", syncToClient = false)
    private void _onChange(ChangeEvent event) {
        _setSelected(defaultify(event.getValue(Boolean.class), true), true, false);
        event = new ChangeEvent(this.getParent(), event.getData(), this);
        EventUtil.send(event);
    }
    
}
