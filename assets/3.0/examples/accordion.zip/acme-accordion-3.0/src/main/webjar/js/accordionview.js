'use strict';

define('acme-accordion', [
	'fujion-core', 
	'fujion-widget',
	'acme-accordion-css'
	], 
	
	function(fujion, Widget) { 
	
	var AccordionView = Widget.UIWidget.extend({
		
		/*------------------------------ Containment ------------------------------*/

		onAddChild: function(child) {
			this.rerender();
		},
		
		/*------------------------------ Other ------------------------------*/
	
		updateSelected: function() {
			this.widget$.accordion('option', 'active', this.getSelected());
		},
		
		getSelected: function() {
			var selected = false;
			
			this.forEachChild(function(child, index) {
				if (child.getState('selected')) {
					selected = index;
					return false;
				}
			});
			
			return selected;
		},
		
		/*------------------------------ Rendering ------------------------------*/
		
		afterRender: function() {
			var self = this;
			this._super();
			
			this.widget$.accordion({
				activate: _activate,
				active: false,
				collapsible: true,
				create: _create,
				header: '> .accordionpane > :first-child'
			});
			
			function _create() {
				setTimeout(function() {
					self.updateSelected();
				});
			}
			
			function _activate(event, ui) {
				_open(ui.oldHeader, false);
				_open(ui.newHeader, true);
			}
			
			function _open(header$, selected) {
				var pane = header$ ? header$.fujion$widget() : null;
				
				if (pane) {
					pane.setState('selected', selected);
					pane.trigger('change', {value: selected});
				}
			}
		},
		
		render$: function() {
			return $('<div/>');
		}
		
		/*------------------------------ State ------------------------------*/
		
	});

	var AccordionPane = Widget.LabeledWidget.extend({
		
		/*------------------------------ Containment ------------------------------*/
		
		anchor$: function() {
			return this.sub$('cnt');
		},
		
		/*------------------------------ Lifecycle ------------------------------*/

		init: function() {
			this._super();
			this.forwardToServer('change');
		},
		
		/*------------------------------ Rendering ------------------------------*/
		
		render$: function() {
			var dom = 
				  '<span>'
				+   '<span id="${id}-lbl"/>'
				+   '<div id="${id}-cnt"/>'
				+ '</span>';
			
			return $(this.resolveEL(dom));
		},
		
		/*------------------------------ State ------------------------------*/
		
		s_label: function(v) {
			this.sub$('lbl').text(v);
		},
		
		s_selected: function(v) {
			this._parent.updateSelected();
		}
	});

	Widget.addon('org.acme', 'AccordionPane', AccordionPane);
	return Widget.addon('org.acme', 'AccordionView', AccordionView);
});
